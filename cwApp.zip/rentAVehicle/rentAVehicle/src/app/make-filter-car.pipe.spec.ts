import { MakeFilterCarPipe } from './make-filter-car.pipe';

describe('MakeFilterCarPipe', () => {
  it('create an instance', () => {
    const pipe = new MakeFilterCarPipe();
    expect(pipe).toBeTruthy();
  });
});
