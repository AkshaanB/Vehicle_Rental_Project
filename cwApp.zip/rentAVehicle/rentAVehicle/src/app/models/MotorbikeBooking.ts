
export class MotorbikeBooking{
    constructor(public plateNumber:string,public email:string,public nic:string,public pickupdate:Date,public dropOffDate:Date){

    }
}