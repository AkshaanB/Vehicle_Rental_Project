
export class CarBooking{
    constructor(public plateNumber:string,public email:string,public nic:string,public pickUpDate:Date,public dropOffDate:Date){

    }
}
