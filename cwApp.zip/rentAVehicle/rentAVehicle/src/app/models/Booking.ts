export class Booking{

    constructor(public plateNumber:string,public email:string,public nic:string,public pickUpdate:Date,public dropOffDate:Date){

    }
}