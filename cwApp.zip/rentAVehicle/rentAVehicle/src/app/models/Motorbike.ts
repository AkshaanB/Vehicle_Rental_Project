import { Vehicle } from './Vehicle';

export class Motorbike{
    plateNumber:String;
    make:String;
    model:String;
    color:String;
    capacity:String;
    transmission:String;
    fuelType:String;
    startType:string;
    bikeType:string;
}
