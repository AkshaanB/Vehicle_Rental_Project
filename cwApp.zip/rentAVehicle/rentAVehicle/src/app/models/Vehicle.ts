export class Vehicle{

}
