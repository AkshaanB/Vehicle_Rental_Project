import { PlateNumberMotorbikeFilterPipe } from './plate-number-motorbike-filter.pipe';

describe('PlateNumberMotorbikeFilterPipe', () => {
  it('create an instance', () => {
    const pipe = new PlateNumberMotorbikeFilterPipe();
    expect(pipe).toBeTruthy();
  });
});
