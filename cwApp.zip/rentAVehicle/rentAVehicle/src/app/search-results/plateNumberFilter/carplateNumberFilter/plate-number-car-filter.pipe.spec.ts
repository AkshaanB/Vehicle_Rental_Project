import { PlateNumberCarFilterPipe } from './plate-number-car-filter.pipe';

describe('PlateNumberCarFilterPipe', () => {
  it('create an instance', () => {
    const pipe = new PlateNumberCarFilterPipe();
    expect(pipe).toBeTruthy();
  });
});
