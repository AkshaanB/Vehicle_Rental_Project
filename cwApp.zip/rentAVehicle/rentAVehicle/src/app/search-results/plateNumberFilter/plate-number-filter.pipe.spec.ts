import { PlateNumberFilterPipe } from './plate-number-filter.pipe';

describe('PlateNumberFilterPipe', () => {
  it('create an instance', () => {
    const pipe = new PlateNumberFilterPipe();
    expect(pipe).toBeTruthy();
  });
});
