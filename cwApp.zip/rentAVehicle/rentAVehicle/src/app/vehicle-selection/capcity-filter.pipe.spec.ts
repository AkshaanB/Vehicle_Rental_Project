import { CapcityFilterPipe } from './capcity-filter.pipe';

describe('CapcityFilterPipe', () => {
  it('create an instance', () => {
    const pipe = new CapcityFilterPipe();
    expect(pipe).toBeTruthy();
  });
});
