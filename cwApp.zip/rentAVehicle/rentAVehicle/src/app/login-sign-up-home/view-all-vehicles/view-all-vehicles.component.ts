import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-view-all-vehicles',
  templateUrl: './view-all-vehicles.component.html',
  styleUrls: ['./view-all-vehicles.component.css']
})
export class ViewAllVehiclesComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
