import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-login-sign-up-home',
  templateUrl: './login-sign-up-home.component.html',
  styleUrls: ['./login-sign-up-home.component.css']
})
export class LoginSignUpHomeComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
