import { MakeFilterMotorbikePipe } from './make-filter-motorbike.pipe';

describe('MakeFilterMotorbikePipe', () => {
  it('create an instance', () => {
    const pipe = new MakeFilterMotorbikePipe();
    expect(pipe).toBeTruthy();
  });
});
